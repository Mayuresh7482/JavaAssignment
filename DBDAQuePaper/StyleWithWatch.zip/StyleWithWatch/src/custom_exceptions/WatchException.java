package custom_exceptions;

@SuppressWarnings("serial")
public class WatchException extends Exception {
	public WatchException(String errmsg) {
		super(errmsg);
	}

}
