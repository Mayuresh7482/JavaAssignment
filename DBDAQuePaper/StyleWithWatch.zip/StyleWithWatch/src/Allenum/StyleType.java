package Allenum;

public enum StyleType {
	CASUAL,SPORT,WEDDING;
}
