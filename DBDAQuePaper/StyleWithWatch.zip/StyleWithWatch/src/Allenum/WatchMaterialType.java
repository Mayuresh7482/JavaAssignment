package Allenum;

public enum WatchMaterialType {
	CERAMIC,STEEL,SILVER;
}
