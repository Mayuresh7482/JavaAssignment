package Allenum;

public enum CategoryType {
	MEN,WOMEN;
}
