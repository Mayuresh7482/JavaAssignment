package Allenum;

public enum BrandType {
	CASIO,TITAN;
}
