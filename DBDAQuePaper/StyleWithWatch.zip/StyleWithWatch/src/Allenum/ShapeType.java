package Allenum;

public enum ShapeType {
	SQUARE,RECTANGLE,ROUND;
}
